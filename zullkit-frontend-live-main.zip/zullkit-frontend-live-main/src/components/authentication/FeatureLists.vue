<script setup>
    import Customizable from "@/components/authentication/features/Customizable.vue";
    import Fortune from "@/components/authentication/features/Fortune.vue";
    import Documentation from "@/components/authentication/features/Documentation.vue";
</script>
<template>
    <Customizable />
    <Fortune />
    <Documentation />
</template>