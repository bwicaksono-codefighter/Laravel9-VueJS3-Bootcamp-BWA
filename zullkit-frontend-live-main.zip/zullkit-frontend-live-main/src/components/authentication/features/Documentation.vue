<script setup>
    import IconBook from '@/components/icons/IconBook.vue';
</script>

<template>
  <div class="mb-12">
    <div class="block mb-2">
      <IconBook />
      <h3 class="inline-block ml-2 text-lg font-semibold">Documentation</h3>
    </div>
    <p class="mt-2 text-lg text-gray-500">
      Accelerate your work with our millions <br />
      of ready-to-use design projects.
    </p>
  </div>
</template>
