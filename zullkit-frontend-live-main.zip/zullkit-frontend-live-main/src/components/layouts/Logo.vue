<script setup>
import { RouterLink } from 'vue-router'
</script>

<template>
    <RouterLink to="/" class="flex items-center">
        <img src="@/assets/img/logo.svg" class="h-8 ml-3 sm:ml-0 sm:h-8" alt="Zullkit Logo" />
    </RouterLink>
</template>