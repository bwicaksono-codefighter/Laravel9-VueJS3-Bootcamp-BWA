<script setup>
  import Hero from '@/components/homepage/Hero.vue'
  import Categories from '@/components/homepage/Categories.vue'
  import Items from '@/components/homepage/Items.vue'
</script>

<template>
  <main>
    <Hero />
    <Categories />
    <Items />
  </main>
</template>
