<script setup>
  import Categories from '@/components/categories/Categories.vue'
</script>

<template>
  <main>
    <Categories />
  </main>
</template>
