<script setup>
  import Items from '@/components/categories/Items.vue'
</script>

<template>
  <main>
    <Items />
  </main>
</template>
